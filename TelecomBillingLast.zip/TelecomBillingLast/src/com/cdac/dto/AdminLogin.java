package com.cdac.dto;

public class AdminLogin {
	    private String adminName;
		private String admpassword;
		public AdminLogin() {
			
		}
		public String getAdminName() {
			return adminName;
		}
		public void setAdminName(String adminName) {
			this.adminName = adminName;
		}
		public String getAdmpassword() {
			return admpassword;
		}
		public void setAdmpassword(String admpassword) {
			this.admpassword = admpassword;
		}
		
}
