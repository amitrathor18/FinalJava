package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="trans_Status")
public class TransctionStatus {
	
	@Column(name="transcId")
	private int transction_Id;
	
	private String status;
	
	public TransctionStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getTransctionId() {
		return transction_Id;
	}
	public void setTransctionId(int transctionId) {
		this.transction_Id = transctionId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return transction_Id + " " + status;
	}
	
	

}
