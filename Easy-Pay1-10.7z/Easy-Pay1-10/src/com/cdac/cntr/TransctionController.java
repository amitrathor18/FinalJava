package com.cdac.cntr;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.dto.Recharge;
import com.cdac.dto.TransctionStatus;
import com.cdac.service.TransctionService;


//@RequestMapping(value="/Transction_form.htm", method= RequestMethod.GET)
//public String prepAddTransction(ModelMap map) {
//public String
//	map.put("Transction",new TransctionStatus());
//	return "Transction.htm";
//}

@Controller
public class TransctionController {
	@Autowired
	private TransctionService transctionService;
	
	@RequestMapping(value="/Transction.htm", method=RequestMethod.POST)
	
	public String addTransctionStatusInDb(TransctionStatus transctionStatus,HttpSession session,ModelMap map)//addRechargeInDb
	{ 
		map.put("transctionStatus",new TransctionStatus());
		int transction_Id = ((TransctionStatus)session.getAttribute("transction_Id")).getTransctionId();
		transctionStatus.setTransctionId(transction_Id);
		transctionService.addTranctionStatus(transctionStatus);
		
		return "home";//TranactionStatus
	}
}
//@RequestMapping(value="/prep_recharge_add_form.htm",method = RequestMethod.GET)
//public String prepAddRecharge(ModelMap map)
//{
//	map.put("recharge",new Recharge());
//	return "recharge_add_form";
//}