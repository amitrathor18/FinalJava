package com.cdac.dao;

import com.cdac.dto.TransctionStatus;

public interface TransctionDao {
	 public void insertTransctionStatus(TransctionStatus transctionStatus);

}
