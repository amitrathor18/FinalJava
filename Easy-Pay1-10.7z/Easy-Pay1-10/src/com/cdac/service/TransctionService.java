package com.cdac.service;

import com.cdac.dto.TransctionStatus;

public interface TransctionService {
	public void addTranctionStatus (TransctionStatus transctionStatus);

}
