package com.cdac.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.TransctionDao;
import com.cdac.dto.TransctionStatus;

@Service
public class TransctionServiceImpl implements TransctionService{

	@Autowired
	private TransctionDao transctiondao;
	
	@Override
	public void addTranctionStatus(TransctionStatus transctionStatus) {
		
		
		transctiondao.insertTransctionStatus(transctionStatus);
	}

}
