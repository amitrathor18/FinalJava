package com.cdac.service;

import com.cdac.dto.Recharge;

public interface RechargeService {
  public void addRechargeDetails(Recharge recharge);
}
