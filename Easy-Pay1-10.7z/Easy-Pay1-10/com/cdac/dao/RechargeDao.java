package com.cdac.dao;

import com.cdac.dto.Recharge;

public interface RechargeDao {
  public void insertRecharge(Recharge recharge);
}
